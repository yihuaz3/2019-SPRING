Select p1.name, p1.address_street from cs122a_sp19.PHLogger p1
where address_state = 'NY';
